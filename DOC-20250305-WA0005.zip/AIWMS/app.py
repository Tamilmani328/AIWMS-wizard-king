from flask import Flask, request, jsonify
import tensorflow as tf
import numpy as np
from tensorflow.keras.preprocessing import image
import os

app = Flask(__name__)

# Load trained model
MODEL_PATH = "waste_classification_model.h5"

if os.path.exists(MODEL_PATH):
    model = tf.keras.models.load_model(MODEL_PATH)
    print("✅ Model Loaded Successfully!")
else:
    print("❌ Model file not found. Ensure 'waste_classification_model.h5' exists.")
    exit()

# Waste categories
waste_categories = ["Organic", "Recyclable", "Hazardous", "General Waste"]

# Image preprocessing function
def preprocess_image(img_path):
    img = image.load_img(img_path, target_size=(224, 224))  # Resize image
    img_array = image.img_to_array(img)
    img_array = np.expand_dims(img_array, axis=0)  # Add batch dimension
    img_array /= 255.0  # Normalize
    return img_array

# Route for waste classification
@app.route("/classify", methods=["POST"])
def classify_waste():
    if "file" not in request.files:
        return jsonify({"error": "No file uploaded"}), 400
    
    file = request.files["file"]
    file_path = "uploaded_image.jpg"
    file.save(file_path)  # Save image

    # Process image and make prediction
    img_array = preprocess_image(file_path)
    prediction = model.predict(img_array)
    class_index = np.argmax(prediction)  # Get highest probability index
    waste_type = waste_categories[class_index]

    return jsonify({"waste_type": waste_type})

if __name__ == "__main__":
    app.run(debug=True)